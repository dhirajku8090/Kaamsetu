KAAMSETU free installable web app (PWA)

Upload all files/folders in this package to the root of your existing GitHub repository named Kaamsetu, replacing the old index.html. Keep the folder name icons and upload both PNG icons. Commit changes. Wait for GitHub Pages to update.

Open https://dhirajku8090.github.io/Kaamsetu/ in Chrome on Android. Tap the three-dot menu and choose Install app (or Add to Home screen).

Note: This is a free installable website app for testing, not yet a Play Store app. Current forms still save only on the same device/browser. A shared online database and secure admin login are needed before public launch.
